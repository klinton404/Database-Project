<?php
session_start();
include 'db.php';

// বুকিং অ্যাকসেপ্ট হ্যান্ডলিং
if (isset($_GET['accept_id'])) {
    $id = $_GET['accept_id'];
    $stmt = $conn->prepare("UPDATE bookings SET status = 'accepted' WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    header("Location: admin_bookings.php?success=Booking+Accepted");
    //header("Location: admin_bookings.php");
    exit();
}

// সব বুকিং ফেচ করা
$result = $conn->query("SELECT * FROM bookings ORDER BY id DESC");
?>

<!DOCTYPE html>
<html>
<head>
    <title>Admin - All Bookings</title>
    <link rel="stylesheet" href="admin_bookings.css">
</head>

<body>
    <h2>All Room Bookings</h2>
    <table>
        <tr>
            <th>ID</th>
            <th>Room ID</th>
            <th>Name</th>
            <th>Phone</th>
            <th>Check-in</th>
            <th>Check-out</th>
            <th>Status</th>
            <th>Action</th>
        </tr>
        <?php while ($row = $result->fetch_assoc()): ?>
        <tr>
            <td><?= $row['id'] ?></td>
            <td><?= $row['room_id'] ?></td>
            <td><?= htmlspecialchars($row['name']) ?></td>
            <td><?= $row['phone'] ?></td>
            <td><?= $row['checkin_date'] ?></td>
            <td><?= $row['checkout_date'] ?></td>
            <td class="<?= $row['status'] == 'accepted' ? 'accepted' : '' ?>">
                <?= ucfirst($row['status']) ?>
            </td>
            <td>
                <?php if ($row['status'] !== 'accepted'): ?>
                    <a class="accept-btn" href="admin_bookings.php?accept_id=<?= $row['id'] ?>">Accept</a>
                <?php else: ?>
                    ✅
                <?php endif; ?>
            </td>
        </tr>
        <?php endwhile; ?>
    </table>

    <div style="text-align: right; margin: 30px 20px;">
    <a href="admin_home.php" style="
        background-color:rgb(110, 114, 117);
        color: white;
        padding: 10px 20px;
        text-decoration: none;
        border-radius: 5px;
        font-weight: bold;
    ">Back to Home</a>
</div>
</body>
</html>