<?php include 'db.php'; ?>

<!DOCTYPE html>
<html>
<head>
  <title>Admin Login</title>
  <link rel="stylesheet" href="form.css">
</head>
<body>

<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_POST['email'];
    $password_input = $_POST['password'];

    $stmt = $conn->prepare("SELECT * FROM admins WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();

    $result = $stmt->get_result();
    $admin = $result->fetch_assoc();

    if ($admin && password_verify($password_input, $admin['password'])) {
        echo "<script>alert('Login successful! Welcome, " . $admin['username'] . "');</script>";
        
        header("Location: admin_home.php");
        exit;

    } else {
        echo "<script>alert('Invalid email or password.');</script>";
    }
}
?>

<form method="POST">
  <h2>Admin Login</h2>
  <input type="email" name="email" placeholder="Email" required><br>
  <input type="password" name="password" placeholder="Password" required><br>
  <button type="submit">Login</button>
  <a href="admin_register.php">Sign Up</a>
</form>
</body>
</html>
