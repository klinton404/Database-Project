<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: user_login.php");
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Facilities - Paradise Hotel</title>
  <link rel="stylesheet" href="facilities.css">
</head>
<body>

  <header>
    <h1>Our Facilities</h1>
    <p>Everything you need for a luxurious and comfortable stay</p>
  </header>

  <section class="facility-list">
    <div class="facility">
      <img src="Pool.jpg" alt="Swimming Pool">
      <h3>Swimming Pool</h3>
      <p>Enjoy our crystal-clear indoor and rooftop swimming pools with relaxing lounge areas.</p>
    </div>

    <div class="facility">
      <img src="Fitness center.jpg" alt="Gym">
      <h3>Fitness Center</h3>
      <p>State-of-the-art gym facilities open 24/7 with personal trainers available on request.</p>
    </div>

    <div class="facility">
      <img src="Spa and wellness.jpg" alt="Spa">
      <h3>Spa & Wellness</h3>
      <p>Relax and rejuvenate with our professional spa, sauna, and massage services.</p>
    </div>

    <div class="facility">
      <img src="Restaurant.jpg" alt="Restaurant">
      <h3>Multi-Cuisine Restaurant</h3>
      <p>Enjoy gourmet dining with a wide range of local and international dishes.</p>
    </div>

    <div class="facility">
      <img src="Room.jpg" alt="Conference Room">
      <h3>Conference & Banquet Halls</h3>
      <p>Fully equipped halls perfect for business meetings, seminars, and social events.</p>
    </div>

    <div class="facility">
      <img src="High speed wifi.jpg" alt="Wi-Fi">
      <h3>Free High-Speed Wi-Fi</h3>
      <p>Stay connected with fast and reliable Wi-Fi available in all rooms and common areas.</p>
    </div>
  </section>


  <div style="text-align: right; margin: 30px 20px;">
        <a href="user_home.php" style="
            background-color: #007BFF;
            color: white;
            padding: 10px 20px;
            text-decoration: none;
            border-radius: 5px;
            font-weight: bold;
        ">Back to Home</a>
    </div>

    

  <footer>
    <p>&copy; 2025 Paradise Hotel. All rights reserved.</p>
  </footer>

</body>
</html>
