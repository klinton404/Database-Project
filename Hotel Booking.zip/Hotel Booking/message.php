<?php
session_start();
include 'db.php';

$user = $_SESSION['full_name'] ?? '';

$stmt = $conn->prepare("SELECT status FROM bookings WHERE name = ? ORDER BY id DESC LIMIT 1");
$stmt->bind_param("s", $user);
$stmt->execute();
$result = $stmt->get_result();
$message = "";

if ($row = $result->fetch_assoc()) {
    if ($row['status'] === 'accepted') {
        $message = "✅ Your booking has been accepted!";
    } else {
        $message = "⏳ Your booking is still pending...";
    }
}

?>
<!DOCTYPE html>
<html>
<head>
    <title>Your Booking Status</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 50px;
            text-align: center;
            background-color: #f9f9f9;
        }

        h2 {
            font-size: 28px;
            color: #333;
        }

        .message {
            font-size: 22px;
            font-weight: bold;
            color: #2c3e50;
            margin: 30px 0;
        }

        .btn-back {
            background-color: rgb(110, 114, 117);
            color: white;
            padding: 12px 24px;
            text-decoration: none;
            border-radius: 6px;
            font-weight: bold;
            display: inline-block;
            transition: background-color 0.3s ease;
        }

        .btn-back:hover {
            background-color: #4e5255;
        }
    </style>
</head>
<body>
    <h2>Booking Message</h2>
    <div class="message"><?= $message ?></div>
    <a class="btn-back" href="user_home.php">Back to Home</a>
</body>
</html>