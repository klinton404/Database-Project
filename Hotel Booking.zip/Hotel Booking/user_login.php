<?php
session_start(); // Start the session
include 'db.php';
?>

<!DOCTYPE html>
<html>
<head>
  <title>User Login</title>
  <link rel="stylesheet" href="form.css">
</head>
<body>

<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_POST['email'];
    $password_input = $_POST['password'];

    $stmt = $conn->prepare("SELECT * FROM users WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();

    $result = $stmt->get_result();
    $user = $result->fetch_assoc();

    if ($user && password_verify($password_input, $user['password'])) {
        // Save user data in session
        $_SESSION['user_id'] = $user['id'];
        $_SESSION['full_name'] = $user['full_name'];
        
        //$_SESSION['email'] = $user['email']; // নতুন লাইন যোগ করুন
        //$_SESSION['name'] = $user['name'];

        // Redirect to user_home.php
        header("Location: user_home.php");
        exit;
    } else {
        echo "<script>alert('Invalid email or password.');</script>";
    }
}
?>

<form method="POST">
  <h2>User Login</h2>
  <input type="email" name="email" placeholder="Email" required><br>
  <input type="password" name="password" placeholder="Password" required><br>
  <button type="submit">Login</button>
  <a href="user_register.php">Sign Up</a>
</form>
</body>
</html>
