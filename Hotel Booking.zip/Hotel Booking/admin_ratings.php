<?php
session_start();
include 'db.php';

// ঐচ্ছিক: এডমিন লগইন চেক
// if (!isset($_SESSION['admin_logged_in'])) {
//     die("Access Denied. Please login as admin.");
// }

$query = "SELECT * FROM ratings ORDER BY created_at DESC";
$result = $conn->query($query);
?>

<!DOCTYPE html>
<html>
<head>
    <title>Admin - Ratings & Reviews</title>
    <link rel="stylesheet" href="admin_ratings.css">
</head>
<body>

    <h2>Ratings & Reviews</h2>

    <?php if ($result->num_rows > 0): ?>
        <table>
            <tr>
                <th>User</th>
                <th>Rating</th>
                <th>Date</th>
            </tr>
            <?php while ($row = $result->fetch_assoc()): ?>
                <tr>
                    <td><?= isset($row['user_name']) ? htmlspecialchars($row['user_name']) : 'Unknown' ?></td>
                    <td>
                        <?php
                        for ($i = 1; $i <= 5; $i++) {
                            echo $i <= $row['rating'] ? '★' : '☆';
                        }
                        ?>
                    </td>
                    <td><?= $row['created_at'] ?></td>
                </tr>
            <?php endwhile; ?>
        </table>
    <?php else: ?>
        <p class="no-data">No ratings submitted yet.</p>
    <?php endif; ?>

    <a href="admin_home.php" class="back-btn">← Back to Admin Home</a>
</body>
</html>