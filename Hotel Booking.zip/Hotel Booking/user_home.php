<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Welcome to Our Hotel</title>
  <link rel="stylesheet" href="user_home.css">
  <style>
    .logout-btn {
      position: absolute;
      top: 20px;
      right: 20px;
      background-color:rgb(78, 63, 62);
      color: white;
      padding: 8px 16px;
      text-decoration: none;
      border-radius: 5px;
      font-weight: bold;
    }

    .logout-btn:hover {
      background-color:rgb(126, 98, 98);
    }

    header {
      position: relative;
    }
  </style>
</head>
<body>

  <header>
    <h1>Welcome to Paradise Hotel</h1>
    <p>Your comfort is our priority</p>
    <a href="logout.php" class="logout-btn">Logout</a>
  </header>

  <nav>
    <ul>
      <li><a href="profile.php">Profile Management</a></li>
      <li><a href="rooms.php">Room</a></li>
      <li><a href="manage_booking.php">Manage Your Room</a></li>
      <li><a href="facilities.php">Facilities</a></li>
      <li><a href="contact.php">Contact Us</a></li>
      <li><a href="rating.php">Rating</a></li>
      <li><a href="message.php">Message</a></li>
      <li><a href="about.php">About</a></li>
    </ul>
  </nav>

  <section class="gallery">
    <h2>Our Hotel</h2>
    <div class="images">
      <img src="Lobby.jpg" alt="Lobby">
      <img src="Room.jpg" alt="Room">
      <img src="Restaurant.jpg" alt="Restaurant">
      <img src="Pool.jpg" alt="Pool">
    </div>
  </section>

  <footer>
    <p>&copy; 2025 Paradise Hotel. All rights reserved.</p>
  </footer>

</body>
</html>
