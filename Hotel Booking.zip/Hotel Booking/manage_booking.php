<?php
session_start();
include 'db.php';

// সেশন চেক করুন
if (!isset($_SESSION['full_name'])) {
    die("Please login first.");
}

$user = $_SESSION['full_name'];

// Handle Update
if (isset($_POST['update'])) {
    $id = $_POST['id'];
    $checkin = $_POST['checkin'];
    $checkout = $_POST['checkout'];

    // সঠিক ফিল্ড নাম ব্যবহার করুন (checkin_date, checkout_date)
    $stmt = $conn->prepare("UPDATE bookings SET checkin_date = ?, checkout_date = ? WHERE id = ?");
    $stmt->bind_param("ssi", $checkin, $checkout, $id);
    $stmt->execute();
    header("Location: manage_booking.php"); // পেজ রিফ্রেশ
    exit();
}

// Handle Cancel
if (isset($_POST['cancel'])) {
    $id = $_POST['id'];
    $stmt = $conn->prepare("DELETE FROM bookings WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    header("Location: manage_booking.php");
    exit();
}

// ফেচ বুকিংস (সঠিক ফিল্ড নাম ব্যবহার করুন)
$stmt = $conn->prepare("SELECT * FROM bookings WHERE name = ?");
$stmt->bind_param("s", $user);
$stmt->execute();
$result = $stmt->get_result();
?>

<!DOCTYPE html>
<html>
<head>
    <title>Manage Your Room</title>
    <link rel="stylesheet" href="manage_booking.css">
</head>
<body>
    <div class="container">
        <h2>Your Room Bookings</h2>
        <?php if ($result->num_rows > 0): ?>
            <?php while ($row = $result->fetch_assoc()): ?>
                <div class="booking-box">
                    <!-- room_name এর বদলে room_id দেখান (অথবা JOIN ব্যবহার করুন) -->
                    <p><strong>Room ID:</strong> <?= $row['room_id'] ?></p>
                    <p><strong>Check-in:</strong> <?= $row['checkin_date'] ?></p>
                    <p><strong>Check-out:</strong> <?= $row['checkout_date'] ?></p>
                    <form method="post">
                        <input type="hidden" name="id" value="<?= $row['id'] ?>">
                        <label>New Check-in:</label>
                        <input type="date" name="checkin" value="<?= $row['checkin_date'] ?>" required>
                        <label>New Check-out:</label>
                        <input type="date" name="checkout" value="<?= $row['checkout_date'] ?>" required>
                        <a href="update_booking.php?id=<?= $row['id'] ?>">
                            <button type="button" class="update-btn">Update</button>
                        </a>
                        <button type="submit" name="cancel">Cancel</button>
                    </form>
                </div>
            <?php endwhile; ?>
        <?php else: ?>
            <p>No bookings found for <?= htmlspecialchars($user) ?>.</p>
        <?php endif; ?>
    </div>

    <div style="text-align: right; margin: 30px 20px;">
    <a href="user_home.php" style="
        background-color: #007BFF;
        color: white;
        padding: 10px 20px;
        text-decoration: none;
        border-radius: 5px;
        font-weight: bold;
        ">Back to Home</a>
    </div>
</body>
</html>