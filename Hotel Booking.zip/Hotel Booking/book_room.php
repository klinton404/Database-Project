<?php include 'db.php'; ?>

<?php
session_start();
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $room_id = $_POST['room_id'];
    $name = $_POST['name'];
    $phone = $_POST['phone'];
    $checkin = $_POST['checkin'];
    $checkout = $_POST['checkout'];
    $adults = $_POST['adults'];
    $children = $_POST['children'];
    $payment_method = $_POST['payment_method'];


$stmt = $conn->prepare("INSERT INTO bookings (room_id, name, phone, checkin_date, checkout_date, adults, children, payment_method) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
$stmt->bind_param("issssiis", $room_id, $name, $phone, $checkin, $checkout, $adults, $children, $payment_method);

    $stmt->execute();

    $_SESSION['full_name'] = $name;
    echo "<script>alert('Booking successful!'); window.location.href='rooms.php';</script>";
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Book Room</title>
    <link rel="stylesheet" href="book_room.css">
</head>
<body>

<div class="form-container">
    <form method="POST">
        <input type="hidden" name="room_id" value="<?php echo $_GET['room_id']; ?>">
        <input type="text" name="name" placeholder="Your Name" required><br>
        <input type="text" name="phone" placeholder="Phone Number" required><br>

        <label>Check-in Date:</label>
        <input type="date" name="checkin" required><br>

        <label>Check-out Date:</label>
        <input type="date" name="checkout" required><br>
        <input type="number" name="adults" placeholder="Adults" min="1" required ><br>
        <input type="number" name="children" placeholder="Children" min="0"><br>

        <label for="payment_method">Payment Method:</label><br>
        <div style="margin-bottom: 15px;">
            <label style="font-weight: bold;">Select Payment Type:</label><br>
            <input type="radio" id="pay_property" name="payment_type" value="Pay at Property" required>
            <label for="pay_property">Pay at Property</label><br>

            <input type="radio" id="pay_cash" name="payment_type" value="Pay on Cash">
            <label for="pay_cash">Pay on Cash</label>
        </div>
        <button type="submit">Submit Booking</button>
    </form>
</div>
</body>
</html>