<?php include 'db.php'; ?>

<?php
session_start();
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $room_id = $_POST['room_id'];
    $name = $_POST['name'];
    $phone = $_POST['phone'];
    $checkin = $_POST['checkin'];
    $checkout = $_POST['checkout'];
    $adults = $_POST['adults'];
    $children = $_POST['children'];
    $payment_method = $_POST['payment_method'];


$stmt = $conn->prepare("INSERT INTO bookings (room_id, name, phone, checkin_date, checkout_date, adults, children, payment_method) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
$stmt->bind_param("issssiis", $room_id, $name, $phone, $checkin, $checkout, $adults, $children, $payment_method);

    $stmt->execute();

    $_SESSION['full_name'] = $name;
    echo "<script>alert('Booking successful!'); window.location.href='rooms.php';</script>";
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Book Room</title>
    <!-- <link rel="stylesheet" href="book_room.css"> -->

    <script>
        window.onload = function () {
            const today = new Date();
            const yyyy = today.getFullYear();
            const mm = String(today.getMonth() + 1).padStart(2, '0');
            const dd = String(today.getDate()).padStart(2, '0');
            const minDate = `${yyyy}-${mm}-${dd}`;

            const checkinInput = document.querySelector('input[name="checkin"]');
            const checkoutInput = document.querySelector('input[name="checkout"]');

            checkinInput.setAttribute('min', minDate);
            checkoutInput.setAttribute('min', minDate);

            checkinInput.addEventListener('change', function () {
                const selectedCheckinDate = checkinInput.value;
                checkoutInput.setAttribute('min', selectedCheckinDate);

                if (checkoutInput.value < selectedCheckinDate) {
                    checkoutInput.value = '';
                }
            });
        }
    </script>




<style>
        body {
    margin: 0;
    padding: 0;
    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    background: linear-gradient(to right,rgb(130, 133, 134),rgb(48, 49, 49));
    display: flex;
    justify-content: center;
    align-items: center;
    height: 100vh;
}

.form-container {
    background: white;
    padding: 40px 30px;
    border-radius: 15px;
    box-shadow: 0 8px 20px rgba(0, 0, 0, 0.2);
    width: 100%;
    max-width: 400px;
}

form h2 {
    text-align: center;
    margin-bottom: 25px;
    color: #333;
}

form input[type="text"],
form input[type="number"],
form input[type="date"] {
    width: 90%;
    padding: 12px 15px;
    margin-bottom: 15px;
    border: 1px solid #ccc;
    border-radius: 8px;
    font-size: 16px;
    transition: border-color 0.3s ease;
}

form input[type="text"]:focus,
form input[type="number"]:focus,
form input[type="date"]:focus {
    border-color: #2980b9;
    outline: none;
}

form label {
    font-weight: 600;
    margin-bottom: 5px;
    display: block;
    color: #333;
}

form input[type="radio"] {
    margin-right: 8px;
}

button[type="submit"] {
    width: 100%;
    padding: 12px;
    background-color: #007bff;
    color: white;
    border: none;
    border-radius: 8px;
    font-size: 16px;
    cursor: pointer;
    transition: background-color 0.3s ease;
}

button[type="submit"]:hover {
    background-color: #0056b3;
}

@media (max-width: 480px) {
    .form-container {
        padding: 30px 20px;
    }
}

</style>
</head>
<body>

<div class="form-container">
    <form method="POST">
        <input type="hidden" name="room_id" value="<?php echo $_GET['room_id']; ?>">
        <input type="text" name="name" placeholder="Your Name" required><br>
        <input type="text" name="phone" placeholder="Phone Number" required><br>

        <label>Check-in Date:</label>
        <input type="date" name="checkin" required><br>

        <label>Check-out Date:</label>
        <input type="date" name="checkout" required><br>
        <input type="number" name="adults" placeholder="Adults" min="1" required ><br>
        <input type="number" name="children" placeholder="Children" min="0"><br>


        <label for="payment_method">Select Payment Method:</label>
        <div style="margin-bottom: 15px;">
            <input type="radio" id="pay_cash" name="payment_method" value="Pay on Cash" checked>
            <label for="pay_cash">Pay on Cash</label>
        </div>
        <button type="submit">Submit Booking</button>
    </form>
</div>
</body>
</html>