<?php
include 'db.php';

if (!isset($_GET['id'])) {
    echo "No booking ID provided.";
    exit;
}

$id = $_GET['id'];
$booking = null;

// Fetch booking data
$stmt = $conn->prepare("SELECT * FROM bookings WHERE id = ?");
$stmt->bind_param("i", $id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows == 0) {
    echo "Booking not found.";
    exit;
}

$booking = $result->fetch_assoc();

// Handle update form submit
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $checkin = $_POST['checkin'];
    $checkout = $_POST['checkout'];

    $update_stmt = $conn->prepare("UPDATE bookings SET checkin_date = ?, checkout_date = ? WHERE id = ?");
    $update_stmt->bind_param("ssi", $checkin, $checkout, $id);
    if ($update_stmt->execute()) {
        echo "<script>alert('Booking updated successfully!'); window.location.href='manage_booking.php';</script>";
    } else {
        echo "Update failed.";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Update Your Booking</title>
    <style>
        form {
            max-width: 400px;
            margin: 50px auto;
            background: #f1f1f1;
            padding: 20px;
            border-radius: 10px;
        }
        input, button {
            display: block;
            width: 100%;
            margin: 15px 0;
            padding: 10px;
        }
        button {
            background: #3498db;
            color: white;
            border: none;
            cursor: pointer;
        }
    </style>
</head>
<body>

<form method="POST">
    <h2>Update Your Booking</h2>
    <label>Room: <?php echo $booking['room_id']; ?> </label>
    <label>Check-in Date:</label>
    <input type="date" name="checkin" value="<?php echo $booking['checkin_date']; ?>" required>

    <label>Check-out Date:</label>
    <input type="date" name="checkout" value="<?php echo $booking['checkout_date']; ?>" required>

    <button type="submit">Update Booking</button>
</form>

</body>
</html>
