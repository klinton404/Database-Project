<?php include 'db.php'; ?>

<!DOCTYPE html>
<html>
<head>
    <title>Complain Box</title>
    <style>
        body {
            font-family: Arial;
            background: #f9f9f9;
            padding: 20px;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            background: white;
        }
        th, td {
            padding: 12px;
            border: 1px solid #ddd;
            text-align: left;
        }
        th {
            background: #2c3e50;
            color: white;
        }
        h2 {
            text-align: center;
        }
    </style>
</head>
<body>

<h2>User Complaints</h2>

<table>
    <tr>
        <th>ID</th>
        <th>Name</th>
        <th>Email</th>
        <th>Problem</th>
        <th>Description</th>
        <th>Received At</th>
    </tr>

    <?php
    $result = $conn->query("SELECT * FROM contact_messages ORDER BY created_at DESC");
    while ($row = $result->fetch_assoc()):
    ?>
        <tr>
            <td><?php echo $row['id']; ?></td>
            <td><?php echo htmlspecialchars($row['name']); ?></td>
            <td><?php echo htmlspecialchars($row['email']); ?></td>
            <td><?php echo htmlspecialchars($row['problem']); ?></td>
            <td><?php echo nl2br(htmlspecialchars($row['description'])); ?></td>
            <td><?php echo $row['created_at']; ?></td>
        </tr>
    <?php endwhile; ?>
</table>

<div style="text-align: right; margin: 30px 20px;">
    <a href="admin_home.php" style="
        background-color:rgb(54, 88, 75);
        color: white;
        padding: 10px 20px;
        text-decoration: none;
        border-radius: 5px;
        font-weight: bold;
    ">Back to Home</a>
</div>

</body>
</html>
