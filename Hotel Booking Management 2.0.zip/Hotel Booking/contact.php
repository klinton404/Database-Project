<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: user_login.php");
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Contact Us - Paradise Hotel</title>
  <link rel="stylesheet" href="contact.css">
</head>
<body>

  <header>
    <h1>Contact Us</h1>
    <p>We're here to help you 24/7</p>
  </header>

  <section class="info">
    <h2>Emergency Contact Info</h2>
    <ul>
      <li><strong>Reception:</strong> +880-1234-567890</li>
      <li><strong>Security:</strong> +880-1987-654321</li>
      <li><strong>Email:</strong> support@paradisehotel.com</li>
    </ul>
  </section>

  <section class="form-section">
    <h2>Send Us a Message</h2>
    <form action="contact_submit.php" method="POST">
      <input type="text" name="name" placeholder="Your Full Name" required>
      <input type="email" name="email" placeholder="Your Email" required>
      
      <select name="problem" required>
        <option value="">Select Problem Type</option>
        <option value="Booking Issue">Booking Issue</option>
        <option value="Room Service">Room Service</option>
        <option value="Payment Problem">Payment Problem</option>
        <option value="Other">Other</option>
      </select>

      <textarea name="description" rows="5" placeholder="Describe your issue here..." required></textarea>

      <button type="submit">Submit</button>
    </form>
  </section>

  <div style="text-align: right; margin: 30px 20px;">
        <a href="user_home.php" style="
            background-color: #007BFF;
            color: white;
            padding: 10px 20px;
            text-decoration: none;
            border-radius: 5px;
            font-weight: bold;
        ">Back to Home</a>
    </div>

  <footer>
    <p>&copy; 2025 Paradise Hotel. All rights reserved.</p>
  </footer>

</body>
</html>
