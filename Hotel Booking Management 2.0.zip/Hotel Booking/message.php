<?php
session_start();
include 'db.php';

$user = $_SESSION['full_name'] ?? '';

$stmt = $conn->prepare("SELECT room_id, status, checkin_date, checkout_date FROM bookings WHERE name = ? ORDER BY id DESC");
$stmt->bind_param("s", $user);
$stmt->execute();
$result = $stmt->get_result();
?>

<!DOCTYPE html>
<html>
<head>
    <title>Your Booking Status</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 50px;
            background-color: #f0f0f0;
        }

        h2 {
            text-align: center;
            font-size: 28px;
            color: #2c3e50;
        }

        .booking {
            background-color: #fff;
            margin: 20px auto;
            padding: 20px;
            max-width: 600px;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0,0,0,0.1);
        }

        .booking p {
            font-size: 18px;
            margin: 8px 0;
        }

        .accepted {
            color: green;
            font-weight: bold;
        }

        .pending {
            color: orange;
            font-weight: bold;
        }

        .btn-back {
            display: block;
            width: fit-content;
            margin: 30px auto;
            background-color: rgb(110, 114, 117);
            color: white;
            padding: 12px 24px;
            text-decoration: none;
            border-radius: 6px;
            font-weight: bold;
            transition: background-color 0.3s ease;
        }

        .btn-back:hover {
            background-color: #4e5255;
        }
    </style>
</head>
<body>
    <h2>Your Booking Messages</h2>

    <?php
    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            echo '<div class="booking">';
            echo '<p><strong>Room ID:</strong> ' . htmlspecialchars($row['room_id']) . '</p>';
            echo '<p><strong>Check-in:</strong> ' . htmlspecialchars($row['checkin_date']) . '</p>';
            echo '<p><strong>Check-out:</strong> ' . htmlspecialchars($row['checkout_date']) . '</p>';
            if ($row['status'] === 'accepted') {
                echo '<p class="accepted">✅ Your booking has been accepted!</p>';
            } else {
                echo '<p class="pending">⏳ Your booking is still pending...</p>';
            }
            echo '</div>';
        }
    } else {
        echo '<div class="booking"><p>No bookings found.</p></div>';
    }
    ?>

    <a class="btn-back" href="user_home.php">Back to Home</a>
</body>
</html>