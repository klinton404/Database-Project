<?php
session_start();
include 'db.php';

// সেশন থেকে ইউজার নাম নিন
$user = $_SESSION['full_name'] ?? 'Guest';

// ফর্ম সাবমিশন হ্যান্ডল করুন
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $rating = (int) $_POST['rating'];

    // ইনপুট ভ্যালিডেশন
    if ($rating >= 0 && $rating <= 5) {
        $stmt = $conn->prepare("INSERT INTO ratings (user_name, rating) VALUES (?, ?)");
        $stmt->bind_param("si", $user, $rating);
        $stmt->execute();
        $message = "Thanks for your rating!";
    } else {
        $message = "Invalid rating value.";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Rate Us</title>
    <link rel="stylesheet" href="rating.css">
</head>
<body>

    <h2>Rate Your Experience at Paradise Hotel</h2>
    
    <form method="POST">
        <div class="stars">
            <input type="radio" name="rating" id="star5" value="5"><label for="star5">&#9733;</label>
            <input type="radio" name="rating" id="star4" value="4"><label for="star4">&#9733;</label>
            <input type="radio" name="rating" id="star3" value="3"><label for="star3">&#9733;</label>
            <input type="radio" name="rating" id="star2" value="2"><label for="star2">&#9733;</label>
            <input type="radio" name="rating" id="star1" value="1"><label for="star1">&#9733;</label>
            <input type="radio" name="rating" id="star0" value="0"><label for="star0">&#9733;</label>
        </div><br>

        <button type="submit" class="submit-btn">Submit Rating</button>
    </form>

    <?php if (isset($message)): ?>
        <div class="message"><?= htmlspecialchars($message) ?></div>
    <?php endif; ?>

    <div style="margin-top: 30px; text-align: center;">
        <a href="user_home.php" class="back-home-btn">← Back to Home</a>
    </div>
</body>
</html>