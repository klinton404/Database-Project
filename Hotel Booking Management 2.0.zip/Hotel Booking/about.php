<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: user_login.php");
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>About - Paradise Hotel</title>
  <link rel="stylesheet" href="about.css">
</head>
<body>

  <header>
    <h1>About Paradise Hotel</h1>
    <p>Where comfort meets luxury</p>
  </header>

  <section class="owner">
    <h2>Owner</h2>
    <div class="card">
      <h3>Mr. Rahim Uddin</h3>
      <p>Founder & Owner</p>
      <p>Mr. Rahim Uddin is a visionary entrepreneur with over 20 years of experience in the hospitality industry. His dedication to comfort, service, and elegance has made Paradise Hotel a premium destination for travelers worldwide.</p>
    </div>
  </section>

  <section class="description">
    <h2>About the Hotel</h2>
    <p>
      Paradise Hotel is a luxurious getaway located in the heart of the city. With beautifully designed rooms, world-class amenities, and exceptional service, we ensure every guest feels like royalty.
    </p>
  </section>

  <section class="employees">
    <h2>Our Team</h2>
    <div class="employee-list">
      <div class="employee-card">
        <h4>Md. Jamal Hossain</h4>
        <p>Hotel Manager</p>
      </div>
      <div class="employee-card">
        <h4>Sabina Yasmin</h4>
        <p>Front Desk Officer</p>
      </div>
      <div class="employee-card">
        <h4>Arif Chowdhury</h4>
        <p>Executive Chef</p>
      </div>
      <div class="employee-card">
        <h4>Fatema Begum</h4>
        <p>Housekeeping Supervisor</p>
      </div>
      <div class="employee-card">
        <h4>Raju Ahmed</h4>
        <p>Security In-Charge</p>
      </div>
    </div>

    <div style="text-align: right; margin: 30px 20px;">
        <a href="user_home.php" style="
            background-color: #007BFF;
            color: white;
            padding: 10px 20px;
            text-decoration: none;
            border-radius: 5px;
            font-weight: bold;
        ">Back to Home</a>
    </div>

  </section>

  <footer>
    <p>&copy; 2025 Paradise Hotel. All rights reserved.</p>
  </footer>

</body>
</html>
