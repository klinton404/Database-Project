<?php include 'db.php'; ?>

<!DOCTYPE html>
<html>
<head>
    <title>Our Rooms</title>
    <link rel="stylesheet" href="rooms.css">
</head>
<body>

<h1 class="title">OUR ROOMS</h1>

<form method="POST" class="filter-box">
    <label>Check-in</label>
    <input type="date" name="checkin" required>
    <label>Check-out</label>
    <input type="date" name="checkout" required>
    <button type="submit">Check Availability</button>
</form>

<?php
$rooms = [
    [
        "id" => 1,
        "name" => "Couple Family Room",
        "image" => "Room1.jpg",
        "price" => 1000,
        "features" => "2 Rooms, 1 Bathroom, 1 Balcony, 3 Sofa",
        "facilities" => ["Wifi", "Television", "AC", "Room heater"],
    ],
    [
        "id" => 2,
        "name" => "Suitable Room",
        "image" => "Room2.jpg",
        "price" => 1500,
        "features" => "3 Rooms, 2 Bathroom, 1 Balcony, 4 Sofa",
        "facilities" => ["Wifi", "Television", "AC", "Minibar"],
    ],
    [
        "id" => 3,
        "name" => "Luxury Room",
        "image" => "Room3.jpg",
        "price" => 800,
        "features" => "1 Rooms, 1 Bathroom, 1 Balcony, 1 Sofa",
        "facilities" => ["Wifi", "Television", "AC", "Minibar"],
    ],
    [
        "id" => 4,
        "name" => "Family Package Room",
        "image" => "Room4.jpg",
        "price" => 2000,
        "features" => "4 Rooms, 2 Bathroom, 1 Balcony, 4 Sofa",
        "facilities" => ["Wifi", "Television", "AC", "Minibar"],
    ],
    [
        "id" => 5,
        "name" => "Comfort Room",
        "image" => "Room5.jpg",
        "price" => 1500,
        "features" => "3 Rooms, 2 Bathroom, 1 Balcony, 4 Sofa",
        "facilities" => ["Wifi", "Television", "AC", "Minibar"],
    ],
    [
        "id" => 6,
        "name" => "Suite Room",
        "image" => "Room6.jpg",
        "price" => 1200,
        "features" => "2 Rooms, 2 Bathroom, 1 Balcony, 2 Sofa",
        "facilities" => ["Wifi", "Television", "AC", "Minibar"],
    ],
    // Add more room arrays here (7th, 8th,...)
];

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $checkin = $_POST['checkin'];
    $checkout = $_POST['checkout'];

    $query = "
        SELECT * FROM rooms WHERE id NOT IN (
            SELECT room_id FROM bookings 
            WHERE (checkin_date < ? AND checkout_date > ?)
        )
    ";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("ss", $checkout, $checkin);
    $stmt->execute();
    $result = $stmt->get_result();

    while ($row = $result->fetch_assoc()) {
        $rooms[] = $row;
    }
}
?>

<div class="room-list">
<?php if (!empty($rooms)): ?>
    <?php foreach ($rooms as $room): ?>
        <div class="room-card">
            <img src="<?php echo $room['image']; ?>" alt="Room Image">
            <div class="room-info">
                <h3><?php echo $room['name']; ?></h3>
                <p><strong>Features:</strong> <?php echo $room['features']; ?></p>
                <p><strong>Facilities:</strong> <?php echo implode(", ", $room['facilities']); ?></p>
                <div class="price-book">
                    <p class="price">৳<?php echo $room['price']; ?> per night</p>
                    <a href="book_room.php?room_id=<?php echo $room['id']; ?>">
                    <button>Book Now</button>
                    </a>
                </div>

            </div>
        </div>
    <?php endforeach; ?>
<?php elseif ($_SERVER["REQUEST_METHOD"] == "POST"): ?>
    <p style="color:red;">এই তারিখে কোনো রুম ফাঁকা নেই।</p>
<?php endif; ?>
</div>
<div>
    <a href="manage_booking.php"></a>
</div>

<div style="text-align: right; margin: 30px 20px;">
    <a href="user_home.php" style="
        background-color: #007BFF;
        color: white;
        padding: 10px 20px;
        text-decoration: none;
        border-radius: 5px;
        font-weight: bold;
    ">Back to Home</a>
</div>

</body>
</html>

</body>
</html>