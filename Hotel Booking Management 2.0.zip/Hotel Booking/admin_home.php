<?php
// session_start();
// যদি লগইন সিস্টেম থাকে তাহলে এখানে session check করতে পারেন
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Admin Dashboard - Paradise Hotel</title>
    <link rel="stylesheet" href="admin_home.css">

    <style>
    .logout-btn {
        position: absolute;
        top: 20px;
        right: 20px;
        background-color:rgb(78, 63, 62);
        color: white;
        padding: 8px 16px;
        text-decoration: none;
        border-radius: 5px;
        font-weight: bold;
    }

    .logout-btn:hover {
        background-color:rgb(88, 81, 81);
    }

    header {
        position: relative;
    }
    </style>


</head>
<body>

<header>
    <h1>Admin Panel - Paradise Hotel</h1>
    <p>Manage Everything from One Place</p>
    <a href="logout.php" class="logout-btn">Logout</a>
</header>

<nav>
    <ul>
        <li><a href="admin_bookings.php">Bookings</a></li>
        <li><a href="admin_ratings.php">Ratings & Review</a></li>
        <li><a href="complains.php">Complain Box</a></li>
    </ul>
</nav>

<div class="container">
    <h2>Hotel Gallery</h2>
    <div class="gallery">
        <img src="Lobby.jpg" alt="Hotel Lobby">
        <img src="Room.jpg" alt="Luxury Room">
        <img src="Restaurant.jpg" alt="Restaurant">
        <img src="Pool.jpg" alt="Swimming Pool">
    </div>
</div>

<footer>
    <p>&copy; 2025 Paradise Hotel Admin Panel</p>
</footer>

</body>
</html>
