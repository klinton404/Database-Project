<?php
session_start();
include 'db.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: user_login.php");
    exit;
}

$user_id = $_SESSION['user_id'];

$stmt = $conn->prepare("SELECT * FROM users WHERE id = ?");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();
$user = $result->fetch_assoc();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $full_name = $_POST['full_name'];
    $email = $_POST['email'];

    if (!empty($_FILES['profile_pic']['name'])) {
        $target_dir = "uploads/";
        $profile_pic = $target_dir . basename($_FILES["profile_pic"]["name"]);
        move_uploaded_file($_FILES["profile_pic"]["tmp_name"], $profile_pic);

        $stmt = $conn->prepare("UPDATE users SET full_name = ?, email = ?, profile_pic = ? WHERE id = ?");
        $stmt->bind_param("sssi", $full_name, $email, $profile_pic, $user_id);
    } else {
        $stmt = $conn->prepare("UPDATE users SET full_name = ?, email = ? WHERE id = ?");
        $stmt->bind_param("ssi", $full_name, $email, $user_id);
    }

    if ($stmt->execute()) {
        echo "<script>alert('Profile updated successfully'); window.location='profile.php';</script>";
    } else {
        echo "<script>alert('Update failed');</script>";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
  <title>Profile Management</title>
  <link rel="stylesheet" href="profile.css">
</head>
<body>

<header>
  <h1>Profile Management</h1>
</header>

<div class="container">
    <form method="POST" enctype="multipart/form-data">
        <div class="profile-pic">
            <img src="<?php echo $user['profile_pic'] ? htmlspecialchars($user['profile_pic']) : 'default-avatar.png'; ?>" alt="Profile Photo">
            <br>
            <input type="file" name="profile_pic">
        </div>

        <label>Full Name</label>
        <input type="text" name="full_name" value="<?php echo htmlspecialchars($user['full_name']); ?>" required>

        <label>Email</label>
        <input type="email" name="email" value="<?php echo htmlspecialchars($user['email']); ?>" required>

        <button type="submit">Save Changes</button>
    </form>

  <div class="password-link">
    <a href="change_password.php">Change Password</a>
  </div>
</div>

<div style="text-align: right; margin: 30px 20px;">
    <a href="user_home.php" style="
        background-color: #007BFF;
        color: white;
        padding: 10px 20px;
        text-decoration: none;
        border-radius: 5px;
        font-weight: bold;
    ">Back to Home</a>
</div>

<footer>
  <p>&copy; 2025 Paradise Hotel</p>
</footer>
</body>
</html>
