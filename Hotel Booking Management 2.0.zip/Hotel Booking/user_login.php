<?php
session_start();
include 'db.php';
?>

<!DOCTYPE html>
<html>
<head>
  <title>User Login</title>
  <link rel="stylesheet" href="form.css">
</head>
<body>

<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_POST['email'];
    $password_input = $_POST['password'];

    $stmt = $conn->prepare("SELECT * FROM users WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();

    $result = $stmt->get_result();
    $user = $result->fetch_assoc();

    if ($user && password_verify($password_input, $user['password'])) {
        $_SESSION['user_id'] = $user['id'];
        $_SESSION['full_name'] = $user['full_name'];
        header("Location: user_home.php");
        exit;
    } else {
        echo "<script>alert('Invalid email or password.');</script>";
    }
}
?>

<form method="POST">
  <h2>User Login</h2>
  <input type="email" name="email" placeholder="Email" required>
  <input type="password" name="password" placeholder="Password" required>
  <button type="submit">Login</button>
  <a href="user_register.php">Sign Up</a>

  <div style="text-align: center; margin-top: 15px;">
    <a href="admin_login.php">Login as Admin</a>
  </div>
</form>

</body>
</html>
