<?php
include 'db.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name       = $_POST['name'];
    $email      = $_POST['email'];
    $problem    = $_POST['problem'];
    $desc       = $_POST['description'];

    $stmt = $conn->prepare("INSERT INTO contact_messages (name, email, problem, description) VALUES (?, ?, ?, ?)");
    $stmt->bind_param("ssss", $name, $email, $problem, $desc);

    if ($stmt->execute()) {
        echo "<script>alert('Message submitted successfully!'); window.location.href='contact.php';</script>";
    } else {
        echo "<script>alert('Failed to submit message.');</script>";
    }
}
?>
