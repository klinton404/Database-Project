<?php
$host = "sql311.infinityfree.com";
$username = "if0_39325489";
$password = "M0MiuETa6L"; // Change this to your DB password
$database = "if0_39325489_hotel_booking";

// Create connection
$conn = new mysqli($host, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}
?>
